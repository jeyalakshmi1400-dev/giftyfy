import React, { useEffect, useState } from "react";
import axios from "axios";
import DeliverySidebar from "../components/DeliverySidebar";
import Select from "react-select";
import { toast } from "react-toastify";
import "../styles/orderPickup.css";

export default function OrderPickup() {

  const [orders, setOrders] = useState([]);
  const [filter, setFilter] = useState("All");

  const [selectedOrder, setSelectedOrder] = useState(null);
  const [delayModal, setDelayModal] = useState(false);
  const [cancelModal, setCancelModal] = useState(false);

  const [delayReason, setDelayReason] = useState("");
  const [cancelReason, setCancelReason] = useState("");
  const [rescheduleDate, setRescheduleDate] = useState("");
const [rescheduleTime, setRescheduleTime] = useState("");
  const [note, setNote] = useState("");

  // ================= FETCH ORDERS =================
  const fetchOrders = async () => {
    try {
      const token = localStorage.getItem("deliveryToken");

      const res = await axios.get(
        "http://localhost:4000/api/delivery/my-orders",
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );

      setOrders(res.data);
    } catch (err) {
      console.log(err);
    }
  };

  useEffect(() => {
    fetchOrders();
    const interval = setInterval(fetchOrders, 5000);
    return () => clearInterval(interval);
  }, []);

  // ================= STATUS UPDATE =================
  const updateStatus = async (id, status) => {
    const token = localStorage.getItem("deliveryToken");

    await axios.put(
      `http://localhost:4000/api/orders/${id}/delivery-status`,
      { status },
      { headers: { Authorization: `Bearer ${token}` } }
    );

    fetchOrders();
  };

  // ================= MODALS =================
  const openDelay = (order) => {
    setSelectedOrder(order);
    setDelayModal(true);
  };

  const openCancel = (order) => {
    setSelectedOrder(order);
    setCancelModal(true);
  };

const submitDelay = async () => {
  try {
    const token = localStorage.getItem("deliveryToken");

    await axios.put(
      `http://localhost:4000/api/orders/${selectedOrder._id}/delay`,
      {
        reason: delayReason,
        note,
         rescheduleDate,
    rescheduleTime,
      },
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    toast.success("Delay reason submitted successfully ✅");

    setDelayModal(false);
    fetchOrders();

  } catch (error) {
    toast.error("Failed to submit delay reason ❌");
    console.log(error);
  }
};



const submitCancel = async () => {
  try {
    const token = localStorage.getItem("deliveryToken");

    await axios.put(
      `http://localhost:4000/api/orders/${selectedOrder._id}/cancel`,
      {
        reason: cancelReason,
      },
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    alert("Order cancelled successfully");

    setCancelModal(false);
    setCancelReason("");

    fetchOrders();

  } catch (error) {
    console.log(error);
    alert("Failed to cancel order");
  }
};

  // ================= FILTER =================
  const filterOptions = [
    { value: "All", label: "All Orders" },
    { value: "Assigned", label: "Assigned" },
    { value: "Out for Delivery", label: "Out For Delivery" },
    { value: "Delivered", label: "Delivered" },
  ];

  const statusOptions = [
    { value: "Assigned", label: "Assigned" },
    { value: "Out for Delivery", label: "Out For Delivery" },
    { value: "Delivered", label: "Delivered" },
  ];

  const filteredOrders = orders.filter((o) => {
    if (o.status === "Delivered") return false;
      if (o.deliveryCancelled) return false;
    if (filter === "All") return true;
    return o.status === filter;
  });

  return (
    <div className="delivery-layout">

      <DeliverySidebar />

      <div className="delivery-main">

        {/* TOP BAR */}
        <div className="pickup-top">

          <div>
            <h2>🚚 My Delivery Orders</h2>
            <p>Manage assigned deliveries</p>
          </div>

          <Select
            value={filterOptions.find(f => f.value === filter)}
            onChange={(e) => setFilter(e.value)}
            options={filterOptions}
            isSearchable={false}
          />

        </div>

        {/* ORDERS */}
        <div className="pickup-orders">

          {filteredOrders.map((order) => (

            <div className="pickup-card" key={order._id}>

              {/* HEADER */}
              <div className="pickup-header">

                <div>
                  <h3>Order #{order._id.slice(-5)}</h3>
                  <p>{new Date(order.createdAt).toLocaleDateString()}</p>
{order.isDelayed && order.status !== "Delivered" && (
  <div className="delay-info">
    <span className="delay-badge">⏰ Delayed</span>

    <p>
      <strong>Reason:</strong> {order.delayReason}
    </p>

    <p>
      <strong>Rescheduled:</strong>
      {order.rescheduleDate} at {order.rescheduleTime}
    </p>
  </div>
)}
                </div>

                <div className="pickup-action-box">

                  <Select
                    value={{ value: order.status, label: order.status }}
                    onChange={(e) => updateStatus(order._id, e.value)}
                    isSearchable={false}
                    options={statusOptions}
                  />

                  <button className="delay-btn" onClick={() => openDelay(order)}>
                    ⏰ 
                  </button>

                  <button className="cancel-btn" onClick={() => openCancel(order)}>
                    ❌ 
                  </button>

                </div>

              </div>

              {/* CUSTOMER */}
              <div className="customer-box">

                <div>
                  <h4>👤 {order.user?.name}</h4>
                  <p>📞 {order.phone}</p>
                  <p>📍 {order.address}</p>
                </div>

                <div>
                  <h3>₹ {order.totalAmount}</h3>
                  <p>{order.paymentMethod}</p>
                </div>

              </div>

              {/* ITEMS */}
            <div className="pickup-items">

  {order.items.map((item, i) => (

    <div className="pickup-item" key={i}>

      <img
        src={
          item.image?.startsWith("uploads")
            ? `http://localhost:4000/${item.image}`
            : `http://localhost:4000/uploads/${item.image}`
        }
        alt={item.name}
      />

      <div className="product-info">
        <h4>{item.name}</h4>
        <p>Quantity : {item.quantity}</p>
        <span>₹ {item.price || 0}</span>
      </div>

    </div>

  ))}

</div>

            </div>

          ))}

        </div>

      </div>

      {/* ================= DELAY MODAL ================= */}
      {delayModal && (
        <div className="popup-overlay">
          <div className="popup-box">

            <h3>⏰ Delay Order</h3>

            <Select
              options={[
                { value: "Traffic", label: "Heavy Traffic" },
                { value: "Rain", label: "Heavy Rain" },
                { value: "Breakdown", label: "Vehicle Issue" },
                { value: "Emergency", label: "Emergency" },
              ]}
              onChange={(e) => setDelayReason(e.value)}
            />

           <input
  type="date"
  value={rescheduleDate}
  onChange={(e) => setRescheduleDate(e.target.value)}
/>

<input
  type="time"
  value={rescheduleTime}
  onChange={(e) => setRescheduleTime(e.target.value)}
/>

            <button onClick={submitDelay}>Submit</button>
            <button onClick={() => setDelayModal(false)}>Close</button>

          </div>
        </div>
      )}

      {/* ================= CANCEL MODAL ================= */}
      {cancelModal && (
        <div className="popup-overlay">
          <div className="popup-box">

            <h3>❌ Cancel Order</h3>

            <Select
              options={[
                { value: "Emergency", label: "Emergency" },
                { value: "Vehicle Issue", label: "Vehicle Issue" },
                { value: "Customer Issue", label: "Customer Not Reachable" },
                { value: "Other", label: "Other" },
              ]}
              onChange={(e) => setCancelReason(e.value)}
            />

            <textarea
              placeholder="Note..."
              onChange={(e) => setNote(e.target.value)}
            />

            <button onClick={submitCancel}>Cancel Order</button>
            <button onClick={() => setCancelModal(false)}>Close</button>

          </div>
        </div>
      )}

    </div>
  );
}