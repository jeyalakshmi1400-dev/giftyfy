import React, { useState, useEffect, useRef } from "react";
import axios from "axios";
import { useParams, useNavigate } from "react-router-dom";
import "../styles/product.css";
import {
  FaTruck,
  FaMoneyBillWave,
  FaUndo,
  FaCheckCircle,
} from "react-icons/fa";

import { toast } from "react-toastify";
import Footer from "../components/Footer";

import ReCAPTCHA from "react-google-recaptcha";



export default function Product() {
  const { id } = useParams();
  console.log("ID =", id);
console.log("TYPE =", typeof id);
  const navigate = useNavigate();

  const [product, setProduct] = useState(null);
  const [mainImage, setMainImage] = useState("");
  const [qty, setQty] = useState(1);
  const [pincode, setPincode] = useState("");
  const [deliveryMsg, setDeliveryMsg] = useState("");
  const [isDeliverable, setIsDeliverable] = useState(false);

  const [selectedVariant, setSelectedVariant] = useState(null);
  const [selectedSize, setSelectedSize] = useState(null);

  const [liked, setLiked] = useState(false);
  const [openInfo, setOpenInfo] = useState(null);

  const imageRef = useRef();
  const lensRef = useRef();
  const zoomRef = useRef();
const [zoomOpen, setZoomOpen] = useState(false);
const [message, setMessage] = useState("");
const [customName, setCustomName] = useState("");

const [recommend, setRecommend] = useState({});
const [recentProducts, setRecentProducts] = useState([]);
const [relatedProducts, setRelatedProducts] = useState([]);
const [similarCategory, setSimilarCategory] = useState([]);
const [extraImages, setExtraImages] = useState([]);

const [reviews, setReviews] = useState([]);
const SITE_KEY = import.meta.env.VITE_RECAPTCHA_SITE_KEY;

console.log("SITE KEY =>", SITE_KEY);

const [captchaToken, setCaptchaToken] = useState("");
const [captcha, setCaptcha] = useState("");
const [captchaInput, setCaptchaInput] = useState("");
const [captchaVerified, setCaptchaVerified] = useState(false);

const isOutOfStock =
  product?.category === "Dress"
    ? (selectedSize?.quantity ?? 0) <= 0
    : (product?.quantity ?? 0) <= 0;

    const generateCaptcha = () => {
  const chars =
    "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789";


  let result = "";

  for (let i = 0; i < 6; i++) {
    result += chars.charAt(
      Math.floor(Math.random() * chars.length)
    );
  }

  return result;
};

useEffect(() => {
  setCaptcha(generateCaptcha());
}, []);

useEffect(() => {
  axios.get(`http://localhost:4000/api/product/recommended/${id}`)
    .then(res => {
       console.log("RECOMMENDED API 👉", res.data);
      setRelatedProducts(
  res.data.sameType?.length
    ? res.data.sameType
    : res.data.exploreMore || []
);

setSimilarCategory(res.data.similarCategory || []);
    });
}, [id]);

useEffect(() => {
  let ids =
    JSON.parse(localStorage.getItem("recent")) || [];

  ids = ids.filter(
    (id) =>
      typeof id === "string" &&
      /^[0-9a-fA-F]{24}$/.test(id)
  );

  if (ids.length === 0) return;

  axios
    .post(
      "http://localhost:4000/api/product/recent",
      { ids }
    )
    .then((res) => {
      setRecentProducts(res.data.slice(0, 3));
    })
    .catch(console.error);

}, [id]);

  // FETCH PRODUCT
useEffect(() => {
  axios.get(`http://localhost:4000/api/product/${id}`).then((res) => {
    const data = res.data;

    setProduct(data);

    // ✅ VARIANT + SIZE AUTO SELECT (FIXED)
    if (data?.variants?.length > 0) {
      const firstVariant = data.variants[0];
      setSelectedVariant(firstVariant);

      // ✅ auto select size
      if (firstVariant?.sizes?.length > 0) {
        setSelectedSize(firstVariant.sizes[0]);
      }

      // ✅ set first image
      const firstImg = firstVariant?.images?.[0];
      if (firstImg) {
        setMainImage(firstImg);
        return; // ✅ ok here
      }
    }

    // ✅ FALLBACK (no variant case)
    const img =
      data?.image?.[0] ||
      data?.image ||
      data?.photos?.[0] ||
      data?.locations?.[0]?.image ||
      "";

    setMainImage(img);
  });
}, [id]);





const userId = localStorage.getItem("userId");

useEffect(() => {
  if (!userId || !id) return;

  axios
    .get(`http://localhost:4000/api/wishlist/${userId}`)
    .then((res) => {
      const exists = res.data.find(
        (item) => item.productId === id
      );

      if (exists) {
        setLiked(true); // ❤️ already in wishlist
      }
    })
    .catch((err) => console.log(err));
}, [id]);





useEffect(() => {

  let recent =
    JSON.parse(localStorage.getItem("recent")) || [];

  // ✅ only valid string ids keep
  recent = recent.filter(
    (item) =>
      typeof item === "string" &&
      item.length === 24
  );

  // ✅ remove duplicate
  recent = recent.filter(
    (item) => item !== id
  );

  // ✅ latest add
  recent.unshift(id);

  // ✅ max 5 items
  if (recent.length > 5) {
    recent.pop();
  }

  localStorage.setItem(
    "recent",
    JSON.stringify(recent)
  );

}, [id]);




useEffect(() => {
  axios
    .get(`http://localhost:4000/api/reviews/product/${id}`)
    .then((res) => {
      setReviews(res.data || []);
    })
    .catch((err) => console.log(err));
}, [id]);





  if (!product) return <h2>Loading...</h2>;

const price =
  selectedSize?.price ||
  selectedVariant?.sizes?.[0]?.price ||
  product?.price ||
  0;


let basePrice =
  selectedSize?.price ||
  selectedVariant?.sizes?.[0]?.price ||
  product?.price ||
  0;

// GST ADD
let priceWithGST = basePrice + (basePrice * (product?.gst || 0)) / 100;

// DISCOUNT APPLY
let finalPrice = priceWithGST;

if (product?.discountType === "percentage") {
  finalPrice =
    priceWithGST - (priceWithGST * product.discountValue) / 100;
}

if (product?.discountType === "flat") {
  finalPrice = priceWithGST - product.discountValue;
}

// ❗ ROUND OFF
finalPrice = Math.round(finalPrice);

if (finalPrice < 0) finalPrice = 0;

  // DELIVERY DATE LOGIC
 const checkPincode = () => {
  if (!pincode || pincode.length !== 6) {
    setDeliveryMsg("❌ Invalid Pincode");
    setIsDeliverable(false);
    return;
  }

  // 🔥 flatten all pincodes from locations
  const allPincodes =
    product?.locations?.flatMap(loc => loc.pincode) || [];

  const isValid = allPincodes.includes(Number(pincode));

  if (isValid) {
    const today = new Date();
    const deliveryDate = new Date(today.setDate(today.getDate() + 3));

    setDeliveryMsg(`✅ Delivery by ${deliveryDate.toDateString()}`);
    setIsDeliverable(true);
  } else {
    setDeliveryMsg("❌ Not deliverable to this pincode");
    setIsDeliverable(false);
  }
};

let allImages = [];

if (selectedVariant?.images?.length > 0) {
  allImages = selectedVariant.images;
} 
else if (product?.image?.length > 0) {   // 🔥 FIX HERE
  allImages = product.image;
} 
else if (product?.photos?.length > 0) {
  allImages = product.photos;
} 
else if (product?.locations?.[0]?.images?.length > 0) {
  allImages = product.locations[0].images;
} 
else if (product?.locations?.[0]?.image) {
  allImages = [product.locations[0].image];
}
  

  // CART
const handleAddToCart = async () => {
  if (isOutOfStock) {
    toast.error("Out of Stock ❌");
    return;
  }

  if (!isDeliverable) {
    alert("Enter valid pincode");
    return;
  }
if (product?.isCustomized) {

  if (!captchaToken) {
    toast.error("Please verify reCAPTCHA");
    return;
  }

  if (!captchaVerified) {
    toast.error("Captcha not verified");
    return;
  }
}
  try {
    const token = localStorage.getItem("token");

    const payload = {
      productId: product._id,
      quantity: qty,
      name: product.name,
      image: mainImage,
      price: finalPrice,
      originalPrice: price,
      discountType: product.discountType || "flat",
      discountValue: product.discountValue || 0,
      gst: product.gst || 0,
    };

    if (selectedSize?.size) payload.size = selectedSize.size;
    if (selectedVariant?.color) payload.variant = selectedVariant.color;

   // ✅ CUSTOMIZATION DATA
if (product?.isCustomized) {
  
  payload.isCustomized = true;

  if (message.trim() !== "") {
    payload.message = message;
  }

  if (customName.trim() !== "") {
    payload.customName = customName;
  }

  // image names only
  if (extraImages.length > 0) {
    payload.extraImages = extraImages;
  }

}

    await axios.post(
      "http://localhost:4000/api/cart/add",
      payload,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    window.dispatchEvent(new Event("cartUpdated"));
    toast.success("Added to cart ✅");

    // ❌ REMOVE navigate here
    // navigate("/cart");

  } catch (err) {
    console.log(err);
    alert("Login required ❌");
  }
};



const handleBuyNow = async () => {

  if (isOutOfStock) {
    alert("❌ Out of Stock");
    return;
  }

  if (!isDeliverable) {
    alert("Enter valid pincode");
    return;
  }

if (product?.isCustomized) {

  if (!captchaToken) {
    toast.error("Please verify reCAPTCHA");
    return;
  }

  if (!captchaVerified) {
    toast.error("Captcha not verified");
    return;
  }
}
  const buyNowItem = {

    _id: product._id,

    productId: product._id,

    // ✅ IMPORTANT
    product: product,

    name: product.name,

    image: mainImage,

    quantity: qty,

    price: finalPrice,

    originalPrice: price,

    size: selectedSize?.size || "",

    variant: selectedVariant?.color || "",

    locations: product.locations || [],

    // ✅ CUSTOMIZATION
    isCustomized:
      product?.isCustomized || false,

    message:
      message.trim() !== ""
        ? message
        : "",

    customName:
      customName.trim() !== ""
        ? customName
        : "",

    extraImages:
      extraImages || [],
  };

  console.log("BUY NOW ITEM 👉", buyNowItem);

  navigate("/checkout", {
    state: {
      buyNow: true,
      item: buyNowItem,
    },
  });

};

  // WISHLIST
const handleWishlist = async () => {
  try {
    if (liked) return;

    const userId = localStorage.getItem("userId");

 const payload = {
  userId,
  productId: product._id,
  name: product.name,

  // ✅ EXACT IMAGE (color based)
  image: selectedVariant?.images?.[0] || "",

  // ✅ EXACT PRICE (size based)
  price: selectedSize?.price || 0,
  originalPrice: selectedSize?.price || 0,

  // ✅ EXACT COMBO
  size: selectedSize?.size,
  variant: selectedVariant?.color,

  // ✅ EXACT STOCK
  sizeQuantity: selectedSize?.quantity || 0,

  category: product.category,
};

    // ✅ BEFORE API CALL ADD THIS
    if (selectedSize?.size) {
      payload.size = selectedSize.size;
      payload.sizeQuantity = selectedSize.quantity;
    }

    if (selectedVariant?.color) {
      payload.variant = selectedVariant.color;
    }

    console.log("WISHLIST PAYLOAD 👉", payload); // debug

    const res = await axios.post(
      "http://localhost:4000/api/wishlist",
      payload
    );

    if (res.data?.message === "Already in wishlist") {
      setLiked(true);
      toast.info("Already in wishlist ❤️");

      
      return;
    }

    setLiked(true);
    alert("Added to wishlist ❤️");
  } catch (err) {
    console.log(err);
    alert("Something went wrong");
  }
};

  const getColor = (color) => {
  if (!color) return "#ccc";

  // hex இருந்தா direct return
  if (color.startsWith("#")) return color;

  // space remove + lowercase
  const clean = color.toLowerCase().replace(/\s+/g, "");

  const colorMap = {
    red: "#ff0000",
    blue: "#0000ff",
    green: "#008000",
    black: "#000000",
    white: "#ffffff",
    yellow: "#ffff00",
    pink: "#ffc0cb",
    orange: "#ffa500",
    purple: "#800080",
    grey: "#808080",
    gray: "#808080",
    brown: "#a52a2a",
    navy: "#000080",
    navyblue: "#000080",
    skyblue: "#87ceeb",
    lightblue: "#add8e6",
    darkgreen: "#006400",
    lightgreen: "#90ee90",
    sandel: "#f4e1c1",
  };

  return colorMap[clean] || "#ccc";
};

  // SERVICE TOGGLE
  const toggleInfo = (type) => {
    setOpenInfo(openInfo === type ? null : type);
  };

  // ZOOM
const handleMouseMove = (e) => {
  const img = imageRef.current;
  const lens = lensRef.current;
  const zoom = zoomRef.current;

  const rect = img.getBoundingClientRect();
  const x = e.clientX - rect.left;
  const y = e.clientY - rect.top;

  const lensSize = 140;

  let lensX = x - lensSize / 2;
  let lensY = y - lensSize / 2;

  lensX = Math.max(0, Math.min(lensX, rect.width - lensSize));
  lensY = Math.max(0, Math.min(lensY, rect.height - lensSize));

  lens.style.left = lensX + "px";
  lens.style.top = lensY + "px";
  lens.style.display = "block";

  zoom.style.display = "block";
  zoom.style.backgroundImage = `url(${img.querySelector("img").src})`;

  const zoomLevel = 3;

  zoom.style.backgroundSize = `${rect.width * zoomLevel}px ${rect.height * zoomLevel}px`;

  zoom.style.backgroundPosition = `-${lensX * zoomLevel}px -${lensY * zoomLevel}px`;
};

  const handleMouseLeave = () => {
    lensRef.current.style.display = "none";
    zoomRef.current.style.display = "none";
  };

 const getImage = (p) => {
  if (p?.variants?.[0]?.images?.length > 0) {
    return p.variants[0].images[0];
  }
  if (p?.images?.length > 0) {
    return p.images[0];
  }
  if (p?.image?.length > 0) {   // 🔥 ADD THIS
    return p.image[0];
  }
  if (p?.photos?.length > 0) {
    return p.photos[0];
  }
  if (p?.locations?.[0]?.image) {
    return p.locations[0].image;
  }
  return null;
};
const calculateFinalPrice = (p) => {

  let basePrice =
    p?.variants?.[0]?.sizes?.[0]?.price ||
    p?.price ||
    0;

  // GST
  let priceWithGST =
    basePrice + (basePrice * (p?.gst || 0)) / 100;

  let final = priceWithGST;

  // DISCOUNT
  if (p?.discountType === "percentage") {
    final =
      priceWithGST -
      (priceWithGST * p.discountValue) / 100;
  }

  if (p?.discountType === "flat") {
    final = priceWithGST - (p.discountValue || 0);
  }

  final = Math.round(final);

  if (final < 0) final = 0;

  return final;
};


const isExtraAllowed =
  product?.isCustomized === true;


  const handleExtraImages = (e) => {
  const files = Array.from(e.target.files);
  setExtraImages(files);
};
const getStock = () => {
  if (product?.category === "Dress") {
    return selectedSize?.quantity ?? 0;
  }
  return product?.quantity ?? 0;
};


const averageRating =
  reviews.length > 0
    ? (
        reviews.reduce((sum, r) => sum + Number(r.rating || 0), 0) /
        reviews.length
      ).toFixed(1)
    : 0;



const verifyCaptcha = (value) => {
  setCaptchaInput(value);

  if (value.trim() === captcha) {
    setCaptchaVerified(true);
  } else {
    setCaptchaVerified(false);
  }
};

const stock = getStock();

const getPercentage = (star) => {
  const count = reviews.filter(
    (r) => Math.round(r.rating) === star
  ).length;

  return reviews.length
    ? Math.round((count / reviews.length) * 100)
    : 0;
};

  return (
<div>
    <div className="product-details">
      

    <div className="gp-product-page">

  {/* BREADCRUMB */}
  <div className="gp-breadcrumb">
    Home &gt; {product.category} &gt; {product.name}
  </div>

  <div className="gp-top-layout">

    {/* THUMBNAILS */}
    <div className="gp-thumb-wrapper">
      <div className="gp-thumb-list">
        {allImages.length > 0 ? (
          allImages.map((img, i) => (
            <img
              key={i}
              src={`http://localhost:4000/uploads/${img}`}
              className={`gpr-thumb-img ${
                mainImage === img ? "gp-thumb-active" : ""
              }`}
              onClick={() => setMainImage(img)}
            />
          ))
        ) : (
          <p>No Images</p>
        )}
      </div>
    </div>

    {/* IMAGE SECTION */}
    <div className="gp-image-section">

      <div
        className="gp-image-box"
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
        ref={imageRef}
      >

        <img
          src={
            mainImage
              ? `http://localhost:4000/uploads/${mainImage}`
              : "https://dummyimage.com/400x400/eee/aaa"
          }
          className="gp-main-image"
          onClick={() => {
            if (window.innerWidth < 768) {
              setZoomOpen(true);
            }
          }}
        />

        {zoomOpen && (
          <div
            className="zoom-modal"
            onClick={() => setZoomOpen(false)}
          >
            <img
              src={`http://localhost:4000/uploads/${mainImage}`}
            />
          </div>
        )}

        <div className="gp-lens" ref={lensRef}></div>
      </div>

      <div className="gp-zoom-preview" ref={zoomRef}></div>

    </div>

    {/* RIGHT PANEL */}
    <div className="gp-right-panel">

      <h2 className="gp-product-title">
        {product.name}
      </h2>
<div className="gp-rating-box">
  {[1, 2, 3, 4, 5].map((star) => (
    <span
      key={star}
      className={
        star <= Math.round(averageRating)
          ? "gp-star-filled"
          : "gp-star-empty"
      }
    >
      ★
    </span>
  ))}

  <span className="gp-rating-text">
    {averageRating} ({reviews.length} Reviews)
  </span>
</div>

      {/* PRICE */}
     <div className="gp-price-card">

  <div className="gp-price-top">
    <span className="gp-final-price">₹{finalPrice}</span>

    <span className="gp-old-price">
      ₹{price}
    </span>

    <span className="gp-discount-badge">
      {product.discountType === "percentage"
        ? `${product.discountValue}% OFF`
        : `₹${product.discountValue} OFF`}
    </span>
  </div>
  



  <p className="gp-tax-text">
    Inclusive of all taxes
  </p>

</div>

      
 

      {/* STOCK */}
      {product?.category === "Dress" ? (
        selectedSize?.quantity < 5 &&
        selectedSize?.quantity > 0 && (
          <p className="gp-low-stock">
            ⚡ Only few left!
          </p>
        )
      ) : (
        product.quantity < 5 &&
        product.quantity > 0 && (
          <p className="gp-low-stock">
            ⚡ Only few left!
          </p>
        )
      )}

      {/* COLORS */}
      {product?.category === "Dress" && (
        <div className="gp-color-section">

          <h4 className="gp-section-title">
            Select Color
          </h4>

          <div className="gp-color-list">
            {product.variants?.map((v, i) => (
              <div
                key={i}
                className={`gp-color-item ${
                  selectedVariant === v ? "active" : ""
                }`}
                onClick={() => {
                  setSelectedVariant(v);
                  setMainImage(v?.images?.[0] || "");
                }}
              >
                <div
                  className="gp-color-circle"
                  style={{
                    background: getColor(v.color),
                  }}
                ></div>

                <span className="gp-color-name">
                  {v.color}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

     {/* SIZE - ONLY FOR DRESS */}
{product?.category === "Dress" && (
  <>
    <h4 className="gp-section-title">
      Select Size
    </h4>

    <div className="gp-size-list">
      {selectedVariant?.sizes?.map((s, i) => (
        <button
          key={i}
          className={`gp-size-btn ${
            selectedSize === s ? "active" : ""
          }`}
          onClick={() => setSelectedSize(s)}
        >
          {s.size}
           <small>{s.quantity}</small>
        </button>
      ))}
    </div>
  </>
)}

      {/* EXTRA */}
     {isExtraAllowed && (
  <div className="gp-customization-section">

    {/* IMAGE FIELD */}
    {product?.customizationFields?.includes("image") && (
      <>
        <div className="gp-extra-box">
          <label>Upload Images</label>

          <input
            type="file"
            multiple
            accept="image/*"
            onChange={handleExtraImages}
          />
        </div>

        {extraImages.length > 0 && (
          <div className="gp-preview-grid">
            {extraImages.map((file, i) => (
              <img
                key={i}
                src={URL.createObjectURL(file)}
                alt=""
              />
            ))}
          </div>
        )}
      </>
    )}

        {/* NAME FIELD */}
    {product?.customizationFields?.includes("name") && (
  <div className="gp-message-box">

    <label>Name</label>

    <input
      type="text"
      placeholder="Enter Name"
      value={customName}
      onChange={(e) =>
        setCustomName(e.target.value)
      }
    />

  </div>
)}

    {/* MESSAGE FIELD */}
    {product?.customizationFields?.includes("message") && (
      <div className="gp-message-box">

        <label>Personal Message</label>

        <textarea
          placeholder="Enter your message..."
          value={message}
          onChange={(e) =>
            setMessage(e.target.value)
          }
        />

      </div>
    )}




      <div className="custom-captcha-box">

  <div className="captcha-display">
    {captcha}
  </div>

 <button
  type="button"
  onClick={() => {
    setCaptcha(generateCaptcha());
    setCaptchaInput("");
    setCaptchaVerified(false);
  }}
  className="captcha-refresh-btn"
>
  ↻
</button>

 <input
  type="text"
  value={captchaInput}
  onChange={(e) =>
    verifyCaptcha(e.target.value)
  }
/>
{captchaInput && (
  <p
    style={{
      color: captchaVerified
        ? "green"
        : "red",
      marginTop: "5px",
    }}
  >
    {captchaVerified
      ? "✅ Captcha Verified"
      : "❌ Invalid Captcha"}
  </p>
)}


    </div>

  </div>
)}
<br></br>

      {/* PINCODE */}
      <div className="gp-pincode-box">

        <h4 className="gp-section-title">
          Delivery Availability
        </h4>

        <div className="gp-pincode-inputs">

          <input
            type="number"
            placeholder="Enter Pincode"
            value={pincode}
            onChange={(e) =>
              setPincode(e.target.value)
            }
          />

          <button onClick={checkPincode}>
            Check
          </button>

        </div>

        <p className="gp-delivery-msg">
          {deliveryMsg}
        </p>

      </div>

      {/* QTY */}
      <div className="gp-qty-box">

        <button
          className="gp-qty-btn"
          onClick={() =>
            setQty(qty > 1 ? qty - 1 : 1)
          }
        >
          -
        </button>

        <span className="gp-qty-number">
          {qty}
        </span>

        <button
          className="gp-qty-btn"
          onClick={() => {
            if (isOutOfStock) return;

            if (qty < stock) {
              setQty(qty + 1);
            }
          }}
          disabled={qty >= stock || isOutOfStock}
        >
          +
        </button>

        {stock > 0 && (
          <p className="gp-stock-info">
            Available: {stock}
          </p>
        )}

      </div>

      {/* ACTIONS */}
      <div className="gp-action-buttons">

        <button
          className="gp-wishlist-btn"
          onClick={handleWishlist}
        >
          {liked ? "❤️" : "♡"}
        </button>

        <button
          className="gp-cart-btn"
          onClick={handleAddToCart}
          disabled={!isDeliverable || isOutOfStock}
        >
          Add To Cart
        </button>

      </div>

      <button
        className="gp-buy-btn"
        onClick={handleBuyNow}
        disabled={isOutOfStock}
      >
        Buy Now
      </button>

      {/* SERVICES */}
      <div className="gp-service-row">

        <div
          className="gp-service-card"
          onClick={() => toggleInfo("delivery")}
        >
          <FaTruck />
          <span>Delivery</span>
        </div>

        <div
          className="gp-service-card"
          onClick={() => toggleInfo("cod")}
        >
          <FaMoneyBillWave />
          <span>COD</span>
        </div>

        <div
          className="gp-service-card"
          onClick={() => toggleInfo("return")}
        >
          <FaUndo />
          <span>Return</span>
        </div>

        <div
          className="gp-service-card"
          onClick={() => toggleInfo("original")}
        >
          <FaCheckCircle />
          <span>Original</span>
        </div>

      </div>

      <div className="gp-service-details">
        {openInfo === "delivery" && (
          <p>Delivered in 2-3 days</p>
        )}

        {openInfo === "cod" && (
          <p>Cash on Delivery available</p>
        )}

        {openInfo === "return" && (
          <p>7 days return policy</p>
        )}

        {openInfo === "original" && (
          <p>100% original product</p>
        )}
      </div>

      {/* REVIEWS */}
     {/* REVIEWS */}

    </div>

  </div>


  {/* CUSTOMER REVIEWS */}

<div className="gp-review-panel-full">

  <div className="gp-review-summary">

    <div className="gp-review-score">
      {averageRating} ★
    </div>

    <div>
      <h3>Customer Reviews</h3>
      <p>{reviews.length} Reviews</p>
    </div>

  </div>

 {reviews.length > 0 && (
  <div className="gp-rating-breakdown">

    <div className="gp-rating-overview">
      <h2>{averageRating} ★</h2>
      <p>{reviews.length} Reviews</p>
    </div>

    <div className="gp-rating-bars">

      <div className="gp-rating-row">
        <span>5★</span>
        <div className="gp-bar">
          <div
            className="gp-fill"
            style={{ width: `${getPercentage(5)}%` }}
          />
        </div>
        <span>{getPercentage(5)}%</span>
      </div>

      <div className="gp-rating-row">
        <span>4★</span>
        <div className="gp-bar">
          <div
            className="gp-fill"
            style={{ width: `${getPercentage(4)}%` }}
          />
        </div>
        <span>{getPercentage(4)}%</span>
      </div>

      <div className="gp-rating-row">
        <span>3★</span>
        <div className="gp-bar">
          <div
            className="gp-fill"
            style={{ width: `${getPercentage(3)}%` }}
          />
        </div>
        <span>{getPercentage(3)}%</span>
      </div>

      <div className="gp-rating-row">
        <span>2★</span>
        <div className="gp-bar">
          <div
            className="gp-fill"
            style={{ width: `${getPercentage(2)}%` }}
          />
        </div>
        <span>{getPercentage(2)}%</span>
      </div>

      <div className="gp-rating-row">
        <span>1★</span>
        <div className="gp-bar">
          <div
            className="gp-fill"
            style={{ width: `${getPercentage(1)}%` }}
          />
        </div>
        <span>{getPercentage(1)}%</span>
      </div>

    </div>
  </div>
)}
 {/* 👇 REVIEW LIST HERE */}
  <div className="gp-review-list">

    {reviews.length === 0 ? (
      <p>No reviews yet</p>
    ) : (
      reviews.map((r) => (
        <div
          key={r._id}
          className="gp-review-card"
        >
          <div className="gp-review-header">
            <strong>{r.user?.name}</strong>

            <span className="gp-review-rating">
              ⭐ {r.rating}
            </span>
          </div>

          <p>{r.comment}</p>
        </div>
      ))
    )}

  </div>

</div>



  {/* DESCRIPTION */}
  <div className="gp-description-box">
    <h3>Description</h3>
    <p>{product.description}</p>
  </div>
  

</div>

  
     
{/* ================= RECENTLY VIEWED ================= */}
<div className="gp-product-section">
  <div className="gp-section-head">
    <h3>Recently Viewed</h3>
    <p>Products you explored recently</p>
  </div>

  <div className="gp-product-slider">
    {recentProducts.map((p) => (
      <div
        className="gp-recommend-card"
        key={p._id}
        onClick={() => {
          navigate(`/product/${p._id}`);
          
        }}
      >
        {/* IMAGE */}
        <div className="gp-card-image-box">
          <img
            src={
              getImage(p)
                ? `http://localhost:4000/uploads/${getImage(p)}`
                : "https://dummyimage.com/300x300/eee/aaa"
            }
            alt={p.name}
            className="gp-card-image"
          />

          {p.discountValue > 0 && (
            <span className="gp-card-offer">
              {p.discountType === "percentage"
                ? `${p.discountValue}% OFF`
                : `₹${p.discountValue} OFF`}
            </span>
          )}
        </div>

        {/* CONTENT */}
        <div className="gp-card-content">
          <h4 className="gp-card-title">
            {p.name}
          </h4>
<div className="gp-card-rating">
  <span>⭐ {p.averageRating || 0}</span>
  <span> ({p.reviewCount || 0} Reviews)</span>
</div>

          <div className="gp-card-price-row">

  <span className="gp-card-price">
    ₹{calculateFinalPrice(p)}
  </span>

  {p.discountValue > 0 && (
    <span className="gp-card-old-price">
      ₹{p.price}
    </span>
  )}

</div>
        </div>
      </div>
    ))}
  </div>
</div>

{/* ================= SAME TYPE PRODUCTS ================= */}
<div className="gp-product-section">
  <div className="gp-section-head">
    <h3>Same Type Products</h3>
    <p>Similar styles picked for you</p>
  </div>

  <div className="gp-product-slider">
    {relatedProducts.map((p) => {

      const finalPrice =
        p.discountType === "percentage"
          ? p.price - (p.price * p.discountValue) / 100
          : p.price - (p.discountValue || 0);

      return (
        <div
          className="gp-recommend-card"
          key={p._id}
          onClick={() => {
            navigate(`/product/${p._id}`);
            
          }}
        >

          {/* IMAGE */}
          <div className="gp-card-image-box">
            <img
              src={
                getImage(p)
                  ? `http://localhost:4000/uploads/${getImage(p)}`
                  : "https://dummyimage.com/300x300/eee/aaa"
              }
              alt={p.name}
              className="gp-card-image"
            />

            {p.discountValue > 0 && (
              <span className="gp-card-offer">
                {p.discountType === "percentage"
                  ? `${p.discountValue}% OFF`
                  : `₹${p.discountValue} OFF`}
              </span>
            )}
          </div>

          {/* CONTENT */}
          <div className="gp-card-content">

            <h4 className="gp-card-title">
              {p.name}
            </h4>

  <div className="gp-card-rating">
  <span>⭐ {p.averageRating || 0}</span>
  <span> ({p.reviewCount || 0} Reviews)</span>
</div>

            {/* PRICE */}
         <div className="gp-card-price-row">

  <span className="gp-card-price">
    ₹{calculateFinalPrice(p)}
  </span>

  {p.discountValue > 0 && (
    <span className="gp-card-old-price">
      ₹{p.price}
    </span>
  )}

</div>

          </div>
        </div>
      );
    })}
  </div>
</div>

{/* ================= YOU MAY ALSO LIKE ================= */}
<div className="gp-product-section">
  <div className="gp-section-head">
    <h3>You May Also Like</h3>
    <p>Trending products curated for you</p>
  </div>

  <div className="gp-product-slider">
    {similarCategory.map((p) => (
      <div
        className="gp-recommend-card"
        key={p._id}
        onClick={() => {
          navigate(`/product/${p._id}`);
          
        }}
      >
        <div className="gp-card-image-box">
          <img
            src={
              getImage(p)
                ? `http://localhost:4000/uploads/${getImage(p)}`
                : "https://dummyimage.com/300x300/eee/aaa"
            }
            alt={p.name}
            className="gp-card-image"
          />

          {p.discountValue > 0 && (
            <span className="gp-card-offer">
              {p.discountType === "percentage"
                ? `${p.discountValue}% OFF`
                : `₹${p.discountValue} OFF`}
            </span>
          )}
        </div>

        <div className="gp-card-content">
          <h4 className="gp-card-title">
            {p.name}
          </h4>

         <div className="gp-card-rating">
  <span>⭐ {p.averageRating || 0}</span>
  <span> ({p.reviewCount || 0} Reviews)</span>
</div>

          <div className="gp-card-price-row">

  <span className="gp-card-price">
    ₹{calculateFinalPrice(p)}
  </span>

  {p.discountValue > 0 && (
    <span className="gp-card-old-price">
      ₹{p.price}
    </span>
  )}

</div>
        </div>
      </div>
    ))}
  </div>
</div>   


 </div>
 <div className="mobile-buy-bar">

  <div>
    <h4>₹{finalPrice}</h4>
  </div>

  <button
    className="mobile-cart-btn"
    onClick={handleAddToCart}
  >
    Cart
  </button>

  <button
    className="mobile-buy-btn"
    onClick={handleBuyNow}
  >
    Buy
  </button>

</div>
 
   
    </div>


  ); 
}