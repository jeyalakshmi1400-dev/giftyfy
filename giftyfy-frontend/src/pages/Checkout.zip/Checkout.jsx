import React, { useEffect, useState } from "react";
import axios from "axios";
import "../styles/checkout.css";
import { useLocation } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

export default function Checkout() {
  const navigate = useNavigate();
  const [showForm, setShowForm] = useState(false);
const location = useLocation();

const [newAddress, setNewAddress] = useState({
  firstName: "",
  email: "",
  phone: "",
  address: "",
  city: "",
  state: "",
  pincode: "",
  type: "home",
});


  const [addresses, setAddresses] = useState([]);
  const [selectedAddress, setSelectedAddress] = useState(null);
  const [cart, setCart] = useState({ items: [], summary: {} });
  const [editingId, setEditingId] = useState(null);
  const [couponCode, setCouponCode] = useState("");
  const [coupons, setCoupons] = useState([]);
  const [showCouponPanel, setShowCouponPanel] = useState(false);
  const [discount, setDiscount] = useState(0);
  const [finalAmount, setFinalAmount] = useState(0);
  const [appliedCoupon, setAppliedCoupon] = useState(null);
  const buyNowData = location.state;
const [sentCouponCode, setSentCouponCode] = useState("");
    const { state } = useLocation();


    const [showUnavailableModal, setShowUnavailableModal] = useState(false);
const [blockedProducts, setBlockedProducts] = useState([]);
const [pendingAddress, setPendingAddress] = useState(null);


  
    const [method, setMethod] = useState("razorpay");
    const [loading, setLoading] = useState(false);
    const buyNowItem = state?.item || null;

  const deliveryPincode = localStorage.getItem("deliveryPincode");

  // 🛒 CART
useEffect(() => {

  // ✅ BUY NOW
  if (buyNowData?.buyNow) {

    const item = buyNowData.item;

    setCart({
      items: [item],
      summary: {
        total: item.price * item.quantity,
        productDiscount: 0,
      },
    });

    return;
  }

  // ✅ NORMAL CART
  const fetchCart = async () => {
    try {

      const res = await axios.get(
        "http://localhost:4000/api/cart",
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );

      setCart(res.data);

    } catch (err) {

      console.log(err);

    }
  };

  fetchCart();

}, []);

  // 📍 ADDRESS
  useEffect(() => {
    const fetchAddresses = async () => {
      const res = await axios.get("http://localhost:4000/api/address", {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });

      setAddresses(res.data);

      if (res.data.length > 0) {
  setSelectedAddress(res.data[0]); // latest first
}
    };

    fetchAddresses();
  }, []);

  // 💰 INITIAL PRICE SET
useEffect(() => {
  setFinalAmount(cart.summary?.total || 0);
}, [cart]);

  useEffect(() => {
  console.log("CART ITEMS:", cart.items);
}, [cart]);

useEffect(() => { const fetchCoupons = async () => { 
  try { const res = await axios.get("http://localhost:4000/api/coupons"); 
    console.log("COUPONS API:", res.data); // 🔥 debug
     setCoupons(res.data.coupons || []); } 
     
     
     catch (err) { console.log(err); } };
      fetchCoupons(); }, []);


      useEffect(() => {
  const savedCoupon = localStorage.getItem("appliedCoupon");
  const savedDiscount = localStorage.getItem("discount");
  const savedFinal = localStorage.getItem("finalAmount");

  if (savedCoupon) {
    setAppliedCoupon(savedCoupon);
  }

  if (savedDiscount) {
    setDiscount(Number(savedDiscount));
  }

  if (savedFinal) {
    setFinalAmount(Number(savedFinal));
  }
}, []);




  // 🎁 SEND COUPON
 const sendCoupon = async () => {
  try {
    const res = await axios.post(
      "http://localhost:4000/api/coupons/send-first",
      {},
      {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      }
    );

    if (res.data.success) {
      setCouponSent(false);   // ✔ KEEP TRUE
      setAppliedCoupon(null); // reset if needed
      alert("🎉 Coupon sent!");
    } else {
      alert(res.data.message);
    }
  } catch (err) {
    alert("Error ❌");
  }
};
const sendSelectedCoupon = async (coupon) => {
  try {
    const res = await axios.post(
      "http://localhost:4000/api/coupons/send",
      {
        code: coupon.code,
      },
      {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      }
    );

    if (res.data.success) {
toast.success("📩 Coupon sent to WhatsApp & Email");
      // Input box-la show
      setCouponCode(coupon.code);

      // Button change panna
      setSentCouponCode(coupon.code);
    } else {
      alert(res.data.message);
    }
  } catch (err) {
    alert("Send failed ❌");
  }
};


  // 🎯 APPLY COUPON
const applyCoupon = async (codeFromBtn) => {

  const code = codeFromBtn || couponCode;

  try {

    const res = await axios.post(
      "http://localhost:4000/api/coupons/apply",
      {
        code,
        userId: localStorage.getItem("userId"),
        cartTotal: cart.summary?.total,
      },
      {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      }
    );

   if (res.data.success) {
  setDiscount(res.data.discount);
  setFinalAmount(res.data.finalAmount);
  setAppliedCoupon(code);

  // ✅ SAVE TO LOCALSTORAGE
  localStorage.setItem("appliedCoupon", code);
  localStorage.setItem("discount", res.data.discount);
  localStorage.setItem("finalAmount", res.data.finalAmount);

  setShowCouponPanel(false);

  toast.success("Coupon Applied Successfully 🎉", {
    position: "top-center",
    autoClose: 2000,
    theme: "colored",
  });
}

else {

      alert(res.data.message);

    }

  } catch (err) {
  toast.error(err.response?.data?.message || "Invalid Coupon");
}
};



  // 🧾 PLACE ORDER
// 🧾 GO TO PAYMENT
const goToPayment = () => {

  if (!selectedAddress) {
    alert("Select address ❌");
    return;
  }

  if (!cart.items || cart.items.length === 0) {
    alert("Cart is empty ❌");
    return;
  }

  const addressPin = String(selectedAddress.pincode);

  // 👇 ADD HERE
  cart.items.forEach((item) => {
    console.log("FULL ITEM:", item);
    console.log("PRODUCT:", item.product);
    console.log("LOCATIONS:", item.product?.locations);
  });

  // ❌ FIND BLOCKED PRODUCTS
  const blockedProducts = cart.items.filter((item) => {

    const locations =
      item.product?.locations || [];

    const allPincodes = locations.flatMap((loc) =>
      loc.pincode.map((p) => String(p))
    );

    if (allPincodes.length === 0) return false;

    return !allPincodes.includes(
      String(selectedAddress.pincode)
    );
  });

  if (blockedProducts.length > 0) {

    const productNames = blockedProducts
      .map((item) => item.product?.name)
      .join(", ");

    alert(
      `❌ ${productNames} is not deliverable to pincode ${addressPin}`
    );

    return;
  }

  navigate("/payment", {
    state: {
      cart,
      selectedAddress,
      finalAmount,
      couponCode: appliedCoupon,
      buyNow: buyNowData?.buyNow || false,
    item: buyNowData?.item || null,
    },
  });
};


const removeCoupon = () => {
  const total = cart.summary?.total || 0;
  const productDiscount = cart.summary?.productDiscount || 0;

  setAppliedCoupon(null);
  setDiscount(0);
  setCouponCode("");
  setFinalAmount(total - productDiscount);

  // ✅ REMOVE FROM STORAGE
  localStorage.removeItem("appliedCoupon");
  localStorage.removeItem("discount");
  localStorage.removeItem("finalAmount");

  toast.info("Coupon removed");
};


const handleChange = (e) => {
  setNewAddress({
    ...newAddress,
    [e.target.name]: e.target.value
  });
};

const saveAddress = async () => {
  try {

    let res;

    // ✏️ EDIT MODE
    if (editingId) {
      res = await axios.put(
        `http://localhost:4000/api/address/${editingId}`,
        newAddress,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );

      // 🔥 update UI (replace old address)
      setAddresses(
        addresses.map((addr) =>
          addr._id === editingId ? res.data : addr
        )
      );

      alert("Address updated successfully ✅");

    } else {
      // ➕ CREATE MODE
      res = await axios.post(
        "http://localhost:4000/api/address",
        newAddress,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );

      setAddresses([res.data, ...addresses]);

      alert("Address added successfully ✅");
    }

    // 🔥 reset form
    setEditingId(null);
    setSelectedAddress(res.data);
    setShowForm(false);

  } catch (err) {
    alert("Save failed ❌");
  }
};






// ❌ DELETE ADDRESS
const deleteAddress = async (id) => {
  try {
    await axios.delete(`http://localhost:4000/api/address/${id}`, {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      },
    });

    setAddresses(addresses.filter((addr) => addr._id !== id));

    if (selectedAddress?._id === id) {
      setSelectedAddress(null);
    }

    alert("Address deleted successfully");
  } catch (err) {
    alert("Delete failed ❌");
  }
};


// ✏️ EDIT ADDRESS (simple version)
const editAddress = (addr) => {
  setShowForm(true);
  setEditingId(addr._id);

  setNewAddress({
    firstName: addr.firstName || "",
    lastName: addr.lastName || "",
    address: addr.address || "",
    landmark: addr.landmark || "",
    city: addr.city || "",
    pincode: addr.pincode || "",
    phone: addr.phone || "",
    altPhone: addr.altPhone || "",
    country: addr.country || "India",
    type: addr.type || "home",
  });
};

 const handlePayment = async () => {
  if (!selectedAddress) {
  alert("Please select an address");
  return;
}

const blockedProducts = cart.items.filter((item) => {

  const locations = item.product?.locations || [];

  const allowedPincodes = locations.flatMap((loc) =>
    loc.pincode.map((pin) => String(pin))
  );

  if (allowedPincodes.length === 0) return false;

  return !allowedPincodes.includes(String(selectedAddress.pincode));
});

if (blockedProducts.length > 0) {
  alert(
    `❌ ${blockedProducts
      .map((p) => p.product?.name)
      .join(", ")} cannot be delivered to ${selectedAddress.pincode}`
  );
  return;
}

if (!cart.items || cart.items.length === 0) {
  toast.error("Your cart is empty");
  navigate("/");
  return;
}

    try {

      setLoading(true);

      // =====================================
      // 💳 ONLINE PAYMENT
      // =====================================
      if (method === "razorpay") {

        // ✅ CHECK SDK
        if (!window.Razorpay) {
          alert("Razorpay SDK not loaded ❌");
          setLoading(false);
          return;
        }

        // ✅ CREATE RAZORPAY ORDER
        const res = await axios.post(
          "http://localhost:4000/api/payment/create-order",
          {
            amount: finalAmount
          },
          {
            headers: {
              Authorization: `Bearer ${localStorage.getItem("token")}`
            }
          }
        );

        const { razorpayOrder, key } = res.data;

        // =====================================
        // RAZORPAY OPTIONS
        // =====================================
        const options = {

          key,

          amount: razorpayOrder.amount,

          currency: "INR",

          order_id: razorpayOrder.id,

          name: "Giftyfy",

          description: "Secure Payment",

          prefill: {
            name: `${selectedAddress?.firstName || ""} ${selectedAddress?.lastName || ""}`,
            contact: selectedAddress?.phone || ""
          },

          theme: {
            color: "#e91e63"
          },

          // =====================================
          // ✅ PAYMENT SUCCESS
          // =====================================
          handler: async function (response) {

            try {

              // ✅ VERIFY PAYMENT
              await axios.post(
                "http://localhost:4000/api/payment/verify",
                response,
                {
                  headers: {
                    Authorization: `Bearer ${localStorage.getItem("token")}`
                  }
                }
              );

              // ✅ CREATE ORDER AFTER PAYMENT SUCCESS
              const orderRes = await axios.post(
                "http://localhost:4000/api/orders",
                {
                  address: selectedAddress.address,
                  phone: selectedAddress.phone,
                  pincode: selectedAddress.pincode,
                  couponCode,
                  paymentMethod: "Online",
                  paymentId: response.razorpay_payment_id,
                  buyNowItem,
                },
                {
                  headers: {
                    Authorization: `Bearer ${localStorage.getItem("token")}`
                  }
                }
              );

              alert("Payment Successful 🎉");

              // ✅ SUCCESS PAGE
              navigate(`/success/${orderRes.data.order._id}`);

            } catch (err) {

              console.log(err);

              alert(
                err.response?.data?.message ||
                "Payment verification failed ❌"
              );
            }
          },

          // =====================================
          // ❌ PAYMENT CANCEL
          // =====================================
          modal: {
            ondismiss: function () {

              alert("Payment cancelled ❌");

            }
          }
        };

        // ✅ OPEN RAZORPAY
        const rzp = new window.Razorpay(options);

        rzp.open();
      }

      // =====================================
      // 🚚 COD
      // =====================================
      else {

        // ✅ CREATE ORDER DIRECTLY
        const orderRes = await axios.post(
          "http://localhost:4000/api/orders",
          {
            address: selectedAddress.address,
            phone: selectedAddress.phone,
            pincode: selectedAddress.pincode,
            couponCode,
            paymentMethod: "COD",
            buyNowItem,
          },
          {
            headers: {
              Authorization: `Bearer ${localStorage.getItem("token")}`
            }
          }
        );

        alert("Order placed successfully ✅");

        navigate(`/success/${orderRes.data.order._id}`);
      }

    } catch (err) {

      console.log(err);

      alert(
        err.response?.data?.message ||
        "Payment failed ❌"
      );

    } finally {

      setLoading(false);

    }
  };
  const subtotal = cart.items.reduce(
  (total, item) => total + (item.originalPrice * item.quantity),
  0
);


const removeUnavailableProducts = async () => {

    try{

        for(const item of blockedProducts){

            await axios.delete(

                `http://localhost:4000/api/cart/remove/${item._id}`,

                {
                    headers:{
                        Authorization:`Bearer ${localStorage.getItem("token")}`
                    }
                }

            );

        }

        const res = await axios.get(

            "http://localhost:4000/api/cart",

            {
                headers:{
                    Authorization:`Bearer ${localStorage.getItem("token")}`
                }
            }

        );

        setCart(res.data);

        setSelectedAddress(pendingAddress);

        setShowUnavailableModal(false);

        toast.success("Unavailable products removed");

    }

    catch(err){

        toast.error("Something went wrong");

    }

}
const moveToWishlistAndRemove = async () => {
  try {
    await axios.post(
      "http://localhost:4000/api/cart/move-undeliverable",
      {
        productIds: blockedProducts.map(item => item.product._id),
      },
      {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      }
    );

    // ✅ Fetch updated cart
    const cartRes = await axios.get(
      "http://localhost:4000/api/cart",
      {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      }
    );

    setCart(cartRes.data);

    // ✅ Close popup
    setShowUnavailableModal(false);

    // ✅ Clear temporary states
    setBlockedProducts([]);
    setPendingAddress(null);

    // ✅ Select address
    setSelectedAddress(pendingAddress);

    toast.success("Products moved to wishlist ❤️");

    // ✅ If cart empty
    

  } catch (err) {
    console.log("MOVE ERROR:", err.response?.data || err);
    toast.error(err.response?.data?.message || "Failed");
  }
};


  return (
    <div className="my-checkout">

      {/* LEFT */}
     <div className="my-left">

  {!showForm ? (
    <>
      <h2>Select Address</h2>

      {addresses.map((addr) => (
        <div
          key={addr._id}
          className={`my-card ${
            selectedAddress?._id === addr._id ? "active" : ""
          }`}
          onClick={() => {

const blocked = cart.items.filter((item) => {

  const locations = item.product?.locations || [];

  const pincodes = locations.flatMap(loc =>
    loc.pincode.map(pin => String(pin))
  );

  if (pincodes.length === 0) return false;

  return !pincodes.includes(String(addr.pincode));

});

if (blocked.length > 0) {

  setBlockedProducts(blocked);

  setPendingAddress(addr);

  setShowUnavailableModal(true);

  return;
}

setSelectedAddress(addr);

  setSelectedAddress(addr);
}}
        >
          <input
            type="radio"
            checked={selectedAddress?._id === addr._id}
            disabled={
              deliveryPincode &&
              addr.pincode !== deliveryPincode
            }
          onChange={() => {

  const blockedProducts = cart.items.filter((item) => {

    const locations = item.product?.locations || [];

    const allowedPincodes = locations.flatMap((loc) =>
      loc.pincode.map((pin) => String(pin))
    );

    if (allowedPincodes.length === 0) return false;

    return !allowedPincodes.includes(String(addr.pincode));
  });

  if (blockedProducts.length > 0) {
    alert(
      `❌ ${blockedProducts
        .map((p) => p.product?.name)
        .join(", ")} cannot be delivered to ${addr.pincode}`
    );
    return;
  }

  setSelectedAddress(addr);
}}
          />

          <div style={{ width: "100%" }}>

            <p
              style={{
                display: "flex",
                alignItems: "center",
                gap: "10px",
              }}
            >
              <b>
                {addr.firstName} {addr.lastName}
              </b>

              <span className={`type-badge ${addr.type}`}>
                {addr.type.toUpperCase()}
              </span>
            </p>

            <p>
              {addr.address}, {addr.city}
            </p>

            <p>{addr.phone}</p>

            <div
              style={{
                marginTop: "8px",
                display: "flex",
                gap: "10px",
              }}
            >
              <button
                className="chedit-btn"
                onClick={(e) => {
                  e.stopPropagation();
                  editAddress(addr);
                }}
              >
                Edit
              </button>

              <button
                className="chdelete-btn"
                onClick={(e) => {
                  e.stopPropagation();
                  deleteAddress(addr._id);
                }}
              >
                Delete
              </button>
            </div>

          </div>
        </div>
      ))}

      <button
        className="add-btn"
        onClick={() => {
          setEditingId(null);

          setNewAddress({
            firstName: "",
            lastName: "",
            address: "",
            landmark: "",
            city: "",
            pincode: "",
            phone: "",
            altPhone: "",
            country: "India",
            type: "home",
          });

          setShowForm(true);
        }}
      >
        + Add New Address
      </button>
    </>
  ) : (
    <>

   
  
<div className="address-form-container">
  <div
    className="address-modal"
    onClick={(e) => e.stopPropagation()}
  >

    {/* HEADER */}
    <div className="address-modal-header">
      <div>
        <h2>{editingId ? "Edit Address" : "Add New Address"}</h2>
        <p>Enter your delivery address</p>
      </div>

      <button
        className="modal-close"
        onClick={() => {
          setShowForm(false);
          setEditingId(null);
        }}
      >
        ✕
      </button>
    </div>

    {/* CONTACT DETAILS */}
    <div className="form-section">
      <h4>Contact Details</h4>

      <div className="row">

        <div className="field">
          <label>Full Name *</label>
          <input
            type="text"
            name="firstName"
            placeholder="Enter Full Name"
            value={newAddress.firstName}
            onChange={handleChange}
          />
        </div>

        <div className="field">
          <label>Mobile Number *</label>
          <input
            type="tel"
            name="phone"
            placeholder="10 Digit Mobile Number"
            value={newAddress.phone}
            onChange={handleChange}
          />
        </div>

      </div>

      <div className="field">
        <label>Email Address</label>
        <input
          type="email"
          name="email"
          placeholder="example@gmail.com"
          value={newAddress.email || ""}
          onChange={handleChange}
        />
      </div>
    </div>

    {/* ADDRESS DETAILS */}
    <div className="form-section">

      <h4>Address Details</h4>

      <div className="field">
        <label>Full Address *</label>

        <textarea
          rows="4"
          name="address"
          placeholder="House No, Street, Area, Landmark"
          value={newAddress.address}
          onChange={handleChange}
        />
      </div>

      <div className="row">

  <div className="field">
    <label>City *</label>
    <input
      type="text"
      name="city"
      value={newAddress.city}
      onChange={handleChange}
      placeholder="Enter City"
    />
  </div>

  <div className="field">
    <label>State *</label>
    <input
      type="text"
      name="state"
      value={newAddress.state}
      onChange={handleChange}
      placeholder="Enter State"
    />
  </div>

</div>

<div className="field">
  <label>Pincode *</label>
  <input
    type="text"
    name="pincode"
    value={newAddress.pincode}
    onChange={handleChange}
    placeholder="Enter Pincode"
  />
</div>

    </div>

    {/* ADDRESS TYPE */}
    <div className="form-section">

      <h4>Save Address As</h4>

      <div className="address-type-box">

        <button
          type="button"
          className={newAddress.type === "home" ? "type-btn active" : "type-btn"}
          onClick={() =>
            setNewAddress({ ...newAddress, type: "home" })
          }
        >
          🏠 Home
        </button>

        <button
          type="button"
          className={newAddress.type === "office" ? "type-btn active" : "type-btn"}
          onClick={() =>
            setNewAddress({ ...newAddress, type: "office" })
          }
        >
          🏢 Office
        </button>

        <button
          type="button"
          className={newAddress.type === "other" ? "type-btn active" : "type-btn"}
          onClick={() =>
            setNewAddress({ ...newAddress, type: "other" })
          }
        >
          📍 Other
        </button>

      </div>

    </div>

    {/* ACTION BUTTONS */}
    <div className="modal-actions">

      <button
        className="cancel-btn"
        onClick={() => {
          setShowForm(false);
          setEditingId(null);
        }}
      >
        Cancel
      </button>

      <button
        className="save-btn"
        onClick={saveAddress}
      >
        {editingId ? "Update Address" : "Save Address"}
      </button>

    </div>

  </div>
</div>
   </>
  )}

</div>


      {/* RIGHT */}
<div className="my-right">

  {cart.items && cart.items.length > 0 ? (
    <>
     <div className="checkout-card">
      <h3>Order Summary</h3>

      {cart.items.map((item) => (
        <div key={item._id} className="checkout-product">
          <img
            src={`http://localhost:4000/uploads/${item.image}`}
            alt={item.name}
            className="checkout-product-img"
          />

          <div className="checkout-product-info">
            <h4>{item.name}</h4>

            <p>
              Qty: {item.quantity} × ₹{item.price}
            </p>

            {item.size && <p>Size: {item.size}</p>}

            {item.variant && <p>Color: {item.variant}</p>}

            <p className="gp-tax-text">
              Inclusive of all taxes
            </p>
          </div>

          <div className="checkout-product-price">
            <h4>₹{item.price * item.quantity}</h4>
          </div>
        </div>
      ))}

      {/* Coupon */}
      <p
        className="view-coupon"
        onClick={() => setShowCouponPanel(true)}
      >
        View More Coupons →
      </p>

      {/* Coupon Panel */}
      {showCouponPanel && (
        <div className="coupon-overlay">
          <div className="coupon-panel">

            <div className="coupon-header">
              <h3>Coupons</h3>
              <span onClick={() => setShowCouponPanel(false)}>✖</span>
            </div>

            <div className="coupon-input-box">
              <input
                placeholder="Enter coupon code"
                value={couponCode}
                onChange={(e) => setCouponCode(e.target.value)}
              />

              <button onClick={() => applyCoupon()}>
                Apply
              </button>
            </div>

            <div className="coupon-list">
              {coupons.length === 0 && (
                <p>No coupons available</p>
              )}

              {coupons.map((c) => (
                <div className="coupon-card" key={c._id}>

                  <div className="coupon-left">
                    <div className="coupon-code">
                      {c.code}
                    </div>

                    <h4>{c.description}</h4>

                    <p className="coupon-offer">
                      {c.discountType === "percentage"
                        ? `${c.discountValue}% OFF`
                        : `₹${c.discountValue} OFF`}
                    </p>

                    <p className="coupon-min">
                      Min Order ₹{c.minOrderAmount}
                    </p>

                    {c.maxDiscount > 0 && (
                      <p className="coupon-max">
                        Max Discount ₹{c.maxDiscount}
                      </p>
                    )}

                    {c.expiryDate && (
                      <p className="coupon-valid">
                        Valid till{" "}
                        {new Date(c.expiryDate).toLocaleDateString()}
                      </p>
                    )}
                  </div>

                  <div className="coupon-right">
                    {appliedCoupon === c.code ? (
                      <button className="coupon-applied">
                        ✔ Applied
                      </button>
                    ) : sentCouponCode === c.code ? (
                      <button
                        className="coupon-apply"
                        onClick={() => applyCoupon(c.code)}
                      >
                        Apply
                      </button>
                    ) : (
                      <button
                        className="coupon-send"
                        onClick={() => sendSelectedCoupon(c)}
                      >
                        Send 📩
                      </button>
                    )}
                  </div>

                </div>
              ))}
            </div>

          </div>
        </div>
      )}

      {appliedCoupon && (
        <p className="applied-show">
          Coupon Applied ✔
          <span onClick={removeCoupon}>✖</span>
        </p>
      )}

      {/* Summary */}
      <div className="giftfy-cart-summary-box">

        <h3>Order Summary</h3>

        <div className="giftfy-summary-line">
          <p>Subtotal</p>
          <h5>
            ₹{subtotal - (cart.summary?.discount || 0)}
          </h5>
        </div>

        <div className="giftfy-summary-line">
          <p>Coupon Discount</p>
          <h5 className="giftfy-summary-red">
            ₹{Math.round(discount)}
          </h5>
        </div>

        <div className="giftfy-summary-line">
          <p>Delivery Fee</p>
          <h5>
            {cart.summary?.delivery === 0
              ? "FREE"
              : `₹${cart.summary?.delivery || 0}`}
          </h5>
        </div>

        <p className="giftfy-summary-tax">
          Inclusive of all taxes
        </p>

        <hr />

        <div className="giftfy-summary-total">
          <p>Total Amount</p>
          <h4>₹{Math.round(finalAmount)}</h4>
        </div>

      </div>

      </div>

      {/* Payment */}
     <div className="payment-card">

    <h3>Select Payment Method</h3>

    <div
      className={`pay-option ${method==="razorpay"?"active":""}`}
      onClick={()=>setMethod("razorpay")}
    >
      <input
        type="radio"
        checked={method==="razorpay"}
        readOnly
      />

      <div>
        <h4>Online Payment</h4>
        <p>UPI • Cards • Net Banking</p>
      </div>
    </div>

    <div
      className={`pay-option ${method==="cod"?"active":""}`}
      onClick={()=>setMethod("cod")}
    >
      <input
        type="radio"
        checked={method==="cod"}
        readOnly
      />

      <div>
        <h4>Cash on Delivery</h4>
        <p>Pay after delivery</p>
      </div>
    </div>

    <button
      className="pay-btn"
      onClick={handlePayment}
      disabled={loading}
    >
      {loading
        ? "Processing..."
        : method==="cod"
        ? "PLACE ORDER"
        : "PAY NOW"}
    </button>

  </div>


      
    </>
  ) : (
    <div className="empty-checkout">
      <h2>Your cart is empty 🛒</h2>
      <p>Please add products to continue checkout.</p>

      <button
        className="continue-shopping-btn"
        onClick={() => navigate("/")}
      >
        Continue Shopping
      </button>
    </div>
  )}

</div>


{showUnavailableModal && (
  <div className="delivery-modal-overlay">
    <div className="delivery-modal">

      <div className="delivery-header">
        <div className="warning-icon">⚠️</div>

        <div>
          <h2>Some products can't be delivered</h2>
          <p>
            These products are unavailable for the selected delivery address.
          </p>
        </div>
      </div>

      <div className="blocked-list">
        {blockedProducts.map((item) => (
          <div className="blocked-item" key={item._id}>
            <div className="blocked-left">
              <span className="blocked-dot"></span>
              <span>{item.product.name}</span>
            </div>

            <span className="blocked-status">
              Not Deliverable
            </span>
          </div>
        ))}
      </div>

      <div className="delivery-note">
        <span>ℹ️</span>
        <p>
          You can remove these products or move them to your wishlist and
          continue checkout.
        </p>
      </div>

      <div className="delivery-actions">
        <button
          className="cancel-btn"
          onClick={() => setShowUnavailableModal(false)}
        >
          Cancel
        </button>

        <button
          className="remove-btn"
          onClick={removeUnavailableProducts}
        >
          Remove & Continue
        </button>

        <button
          className="wishlist-btn"
          onClick={moveToWishlistAndRemove}
        >
          ❤️ Move to Wishlist
        </button>
      </div>

    </div>
  </div>
)}


    </div>
  );
}