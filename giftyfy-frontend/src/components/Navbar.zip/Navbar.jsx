import { Link, useNavigate } from "react-router-dom";
import "./Navbar.css";
import { useEffect, useState, useRef } from "react";
import axios from "axios";
import Collapse from "bootstrap/js/dist/collapse";

function Navbar() {
  const navigate = useNavigate();
  const token = localStorage.getItem("token");

  const [logo, setLogo] = useState(null);
  const [search, setSearch] = useState("");
  const [suggestions, setSuggestions] = useState([]);
  const [category, setCategory] = useState("All");
  const [subcategory, setSubcategory] = useState("All");
  const [cartCount, setCartCount] = useState(0);
  const [menuOpen, setMenuOpen] = useState(false);
const navbarRef = useRef(null);
const [showSearch, setShowSearch] = useState(false);

  const boxRef = useRef(); // ✅ for outside click

  // ===== LOGO FETCH =====
  useEffect(() => {

  const fetchLogo = async () => {

    const res = await axios.get(
      "http://localhost:4000/api/logo"
    );


    setLogo(res.data);

  };

  fetchLogo();

}, []);
useEffect(() => {
  const navbar = document.getElementById("navbarContent");

  const closeMenu = () => {
    setMenuOpen(false);
  };

  navbar?.addEventListener(
    "hidden.bs.collapse",
    closeMenu
  );

  return () => {
    navbar?.removeEventListener(
      "hidden.bs.collapse",
      closeMenu
    );
  };
}, []);

  // ===== SEARCH SUGGESTIONS =====
  useEffect(() => {
    if (search.length > 1) {
      axios.get("http://localhost:4000/api/product")
        .then((res) => {
          const filtered = res.data.filter((p) =>
            p.name.toLowerCase().includes(search.toLowerCase()) ||
            p.category?.toLowerCase().includes(search.toLowerCase()) ||
            p.subcategory?.toLowerCase().includes(search.toLowerCase())
          );
          setSuggestions(filtered.slice(0, 5));
        });
    } else {
      setSuggestions([]);
    }
  }, [search]);

  // ===== OUTSIDE CLICK CLOSE =====
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (boxRef.current && !boxRef.current.contains(e.target)) {
        setSuggestions([]);
      }
    };

    document.addEventListener("click", handleClickOutside);
    return () => {
      document.removeEventListener("click", handleClickOutside);
    };
  }, []);


useEffect(() => {

  const fetchCart = async () => {

    try {

      const token = localStorage.getItem("token");

      if (!token) return;

      const res = await axios.get(
        "http://localhost:4000/api/cart",
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      console.log("CART 👉", res.data);

      // ✅ cart items
      const items = res.data.items || [];

      // ✅ quantity total
      const totalCount = items.reduce(
        (sum, item) => sum + item.quantity,
        0
      );

      setCartCount(totalCount);

    } catch (err) {
      console.log(err);
    }
  };

  fetchCart();

  window.addEventListener("cartUpdated", fetchCart);

  return () => {
    window.removeEventListener("cartUpdated", fetchCart);
  };

}, []);


  // ===== SEARCH BUTTON =====
  const handleSearch = (e) => {
    e.preventDefault();

    if (!search.trim()) return;

    let url = `/products?search=${search}`;

    if (category !== "All") {
      url += `&category=${category}`;
    }

    if (subcategory !== "All") {
      url += `&subcategory=${subcategory}`;
    }

    navigate(url);
    setSuggestions([]); // ✅ close dropdown

      closeMobileMenu();

  };

  // ===== LOGOUT =====
  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/login");
  };

const closeMobileMenu = () => {
  setMenuOpen(false);

  if (navbarRef.current) {
    const bsCollapse =
      Collapse.getInstance(navbarRef.current) ||
      new Collapse(navbarRef.current, {
        toggle: false,
      });

    bsCollapse.hide();
  }
};

  return (
    <nav className="navbar navbar-expand-lg navbar-dark custom-navbar">
      <div className="container">
       

        {/* LOGO */}
        <Link className="navbar-brand" to="/">
 <img
  src={
    logo?.image
      ? `http://localhost:4000/uploads/${encodeURIComponent(logo.image)}`
      : "/no-logo.png"
  }
  alt="Logo"
  className="navbar-logo"
/>
        </Link>

      <button
  className="navbar-toggler"
  type="button"
  data-bs-toggle="collapse"
  data-bs-target="#navbarContent"
  aria-controls="navbarContent"
  aria-expanded={menuOpen}
  aria-label="Toggle navigation"
  onClick={() => setMenuOpen(!menuOpen)}
>
  <i
    className={`bi ${
      menuOpen
        ? "bi-x-lg"
        : "bi-list"
    }`}
  ></i>
</button>

        <div   ref={navbarRef} className="collapse navbar-collapse" id="navbarContent">

          {/* LEFT LINKS */}
          <ul className="navbar-nav">
            <li className="nav-item">
              <Link className="nav-link text-white"  onClick={closeMobileMenu} to="/">Home</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link text-white"  onClick={closeMobileMenu} to="/about">About</Link>
            </li>
            
            <li className="nav-item">
              <Link className="nav-link text-white"  onClick={closeMobileMenu} to="/contact">Contact</Link>
            </li>
          </ul>

          {/* SEARCH */}
 <div className="search-wrapper" ref={boxRef}>

  {!showSearch ? (

    <button
      className="search-icon-btn"
      onClick={() => setShowSearch(true)}
    >
      <i className="bi bi-search"></i>
    </button>

  ) : (

    <div className="search-box">

      <div className="input-group">

        <input
          type="text"
          className="form-control search-input"
          placeholder="Search gifts..."
          value={search}
          onChange={(e) =>
            setSearch(e.target.value)
          }
        />

        <button
          className="btn search-btn"
          onClick={handleSearch}
        >
          <i className="bi bi-search"></i>
        </button>

        <button
          className="btn close-search-btn"
          onClick={() => {
            setShowSearch(false);
            setSearch("");
            setSuggestions([]);
          }}
        >
          <i className="bi bi-x-lg"></i>
        </button>

      </div>

      {suggestions.length > 0 && (

        <div className="search-dropdown">

          {suggestions.map((item) => (

            <div
              key={item._id}
              className="search-item"
              onClick={() => {

                navigate(`/products/${item._id}`);

                setSuggestions([]);

                setSearch("");

                setShowSearch(false);

                closeMobileMenu();

              }}
            >

              <img
                src={`http://localhost:4000/uploads/${item.images?.[0]}`}
                className="search-thumb"
                alt={item.name}
              />

              <div className="search-info">

                <h6>{item.name}</h6>

                <span>
                  ₹{item.offerPrice || item.price}
                </span>

              </div>

            </div>

          ))}

        </div>

      )}

    </div>

  )}

</div>

          {/* RIGHT ICONS */}
          <ul className="navbar-nav ms-auto align-items-center">
            <li className="nav-item me-3">
  <Link to="/orders" className="nav-link text-white " onClick={closeMobileMenu}>
    <i className="bi bi-bag-check fs-5"></i>
  </Link>
</li>

            <li className="nav-item me-3">
              <Link to="/wishlist" className="nav-link text-white"  onClick={closeMobileMenu}>
  <i className="bi bi-heart fs-5"></i>
</Link>
            </li>

   <li className="nav-item me-3 cart-nav-item">
  <Link className="nav-link text-white cart-link" to="/cart" onClick={closeMobileMenu}>

    <i className="bi bi-cart3 cart-icon"></i>

    {cartCount > 0 && (
      <span className="cart-badge">
        {cartCount}
      </span>
    )}

  </Link>
</li>



            <li className="nav-item me-3">
  <Link to="/profile" className="nav-link text-white"  onClick={closeMobileMenu}>
    <i className="bi bi-person-circle fs-5"></i>
  </Link>
</li>

            {!token ? (
              <li className="nav-item">
                <Link className="nav-link text-white" to="/login"  onClick={closeMobileMenu}>
                  Login
                </Link>
              </li>
            ) : (
              <li className="nav-item">
                <button
                  className="btn btn-light"
                  onClick={handleLogout}
                >
                  Logout
                </button>
              </li>
            )}
          </ul>

        </div>
      </div>
    </nav>
  );
}

export default Navbar;