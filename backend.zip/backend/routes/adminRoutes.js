const express = require("express");
const router = express.Router();

const {protect} = require("../middleware/authMiddleware");
const adminOnly= require("../middleware/adminMiddleware");

const { getDashboardStats } = require("../controllers/adminDashboardController");

const 
{approveDeliveryPartner,getAllDeliveryPartners} = require("../controllers/deliveryPartnerController");
const Product = require("../models/Product");


// ✅ GET ALL DELIVERY PARTNERS
router.get(
  "/delivery-partners",
  protect,
  adminOnly,
  getAllDeliveryPartners
);

// ✅ APPROVE DELIVERY PARTNER
router.put(
  "/delivery-partners/:id/approve",
  protect,
  adminOnly,
 approveDeliveryPartner
);

router.get(
  "/dashboard-stats",
  protect,
  adminOnly,
  getDashboardStats
);

module.exports = router;