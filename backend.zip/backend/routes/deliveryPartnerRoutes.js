const express = require("express");
const router = express.Router();

const {
  registerDeliveryPartner
} = require("../controllers/deliveryPartnerController");

// REGISTER delivery partner
router.post("/register", registerDeliveryPartner);



const {deliveryAuthMiddleware} = require("../middleware/deliveryAuthMiddleware");
const { acceptOrder } = require("../controllers/orderController");

// 🚚 ACCEPT ORDER
router.put(
  "/orders/:id/accept",
  deliveryAuthMiddleware,
  acceptOrder
);



module.exports = router;