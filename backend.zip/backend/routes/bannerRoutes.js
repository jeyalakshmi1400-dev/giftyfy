const express =require("express");
const router =express.Router();

const upload =require("../middleware/upload");
const{ addBanner,getBanners,deleteBanner} =require("../controllers/bannerController");


router.post("/",upload.single("image"),addBanner);

router.get("/",getBanners);

router.delete("/:id",deleteBanner);

module.exports=router;