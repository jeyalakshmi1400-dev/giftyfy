const express = require("express");
const router = express.Router();

const {
  placeOrder,
  getMyOrders,
  getAllOrders,
  updateOrderStatus,
  assignDeliveryPartner,
  acceptOrder,
  updateDeliveryStatus,cancelOrder,processRefund
} = require("../controllers/orderController");

const {protect} = require("../middleware/authMiddleware");
const adminOnly= require("../middleware/adminMiddleware");

const {deliveryAuthMiddleware} = require("../middleware/deliveryAuthMiddleware");

// USER
router.post("/", protect, placeOrder);
router.get("/my-orders", protect, getMyOrders);

// ADMIN
router.get("/", protect,adminOnly, getAllOrders);
router.put("/:id/status",protect,adminOnly, updateOrderStatus);
router.put("/:id/assign", adminOnly, assignDeliveryPartner);

// DELIVERY
router.put("/:id/accept", deliveryAuthMiddleware, acceptOrder);
router.put("/:id/delivery-status", deliveryAuthMiddleware, updateDeliveryStatus);
router.put("/:id/cancel", protect, cancelOrder);
router.put("/:id/refund", protect, adminOnly, processRefund);
module.exports = router;