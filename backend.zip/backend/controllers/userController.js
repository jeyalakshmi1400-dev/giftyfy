const User = require("../models/User");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

/* =========================
   REGISTER USER
========================= */
const registerUser = async (req, res) => {
  try {
    const { name, email, password } = req.body;

    // 1️⃣ check user exists
    const userExists = await User.findOne({ email });
    if (userExists) {
      return res.status(400).json({ message: "User already exists" });
    }

    // 2️⃣ hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // 3️⃣ create user
    const user = await User.create({
      name,
      email,
      password: hashedPassword,
      isAdmin: false // default user
    });

    res.status(201).json({
      message: "User registered successfully",
      userId: user._id
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

/* =========================
   LOGIN USER
========================= */
// LOGIN
const loginUser = async (req, res) => {
  try {
    const { email, password } = req.body;

    const user = await User.findOne({ email });

console.log("🔥 LOGIN CONTROLLER HIT");
console.log("🔥 isAdmin from DB =", user.isAdmin);

const token = jwt.sign(
  {
    id: user._id,
    isAdmin: user.isAdmin
  },
  process.env.JWT_SECRET,
  { expiresIn: "7d" }
);
   res.json({
      message: "Login successful",
      token
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  registerUser,
  loginUser
};