const Razorpay = require("razorpay");
const crypto = require("crypto");
const Payment = require("../models/Payment");
const Order = require("../models/Order");

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET
});


// ===========================
// 1️⃣ CREATE RAZORPAY ORDER
// ===========================
const createPaymentOrder = async (req, res) => {
  try {
    const { orderId } = req.body;

    const order = await Order.findById(orderId);
    if (!order) {
      return res.status(404).json({ message: "Order not found" });
    }

    const options = {
      amount: order.totalAmount * 100, // paisa
      currency: "INR",
      receipt: order._id.toString()
    };

    const razorpayOrder = await razorpay.orders.create(options);

    // Save in DB
    await Payment.create({
      user: order.user,
      order: order._id,
      razorpay_order_id: razorpayOrder.id,
      amount: order.totalAmount
    });

    res.json({
      key: process.env.RAZORPAY_KEY_ID,
      razorpayOrder
    });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};


// ===========================
// 2️⃣ VERIFY PAYMENT (TEMP BYPASS)
// ===========================
const verifyPayment = async (req, res) => {
  try {
    const {
      razorpay_order_id,
      razorpay_payment_id
    } = req.body;

    // 🔥 Skip signature verification temporarily

    const payment = await Payment.findOne({ razorpay_order_id });

    if (!payment) {
      return res.status(404).json({ message: "Payment record not found" });
    }

    // ✅ Update Payment
    payment.razorpay_payment_id = razorpay_payment_id;
    payment.status = "Success";
    await payment.save();

    // ✅ VERY IMPORTANT – Update Order Status
    const order = await Order.findById(payment.order);

    if (order) {
      order.status = "Confirmed";
      await order.save();
    }

    res.json({
      message: "Payment successful (Signature bypassed for testing)",
      order
    });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
module.exports = {
  createPaymentOrder,
  verifyPayment
};