const approveDeliveryPartner = async (req, res) => {
  const partner = await DeliveryPartner.findById(req.params.id);

  if (!partner) {
    return res.status(404).json({ message: "Partner not found" });
  }

  partner.isApproved = true;
  await partner.save();

  res.json({
    message: "Delivery partner approved successfully"
  });
};