const  Banner = require("../models/Banner");

exports.addBanner=async(req,res)=>{
    try{
        const banner =new Banner({
            image:req.file.filename,
        });
        await banner.save();

        res.status(201).json({
            message:"Banner Uploadd Successfully",
            banner,
        });

    }
    catch(error){
        res.status(500).json({message:error.message});
    }
};

exports.getBanners =async(req,res)=>{
    try{
        const banners= await Banner.find();
        res.json(banners);
    
    } catch(error){
        res.status(500).json({message:error.message});
    }
};

//delete

exports.deleteBanner =async(req,res)=>{
    try{
        await Banner.findByIdAndDelete(req.params.id); 4

        res.json({
            message:"Banner deleted successfully",
        });
    
    }catch(error){
        res.status(500).json({message:error.message});
    }
};