const Order = require("../models/Order");
const User = require("../models/User");
const DeliveryPartner = require("../models/DeliveryPartner");
const Product = require("../models/Product");

// 📊 GET DASHBOARD STATS
const getDashboardStats = async (req, res) => {
  try {

    const totalOrders = await Order.countDocuments();
    const totalUsers = await User.countDocuments();
    const totalDeliveryPartners = await DeliveryPartner.countDocuments();

    // 💰 Total Revenue (Only Delivered Orders)
    const revenueData = await Order.aggregate([
      { $match: { status: "Delivered" } },
      {
        $group: {
          _id: null,
          totalRevenue: { $sum: "$totalAmount" }
        }
      }
    ]);

    const totalRevenue = revenueData.length > 0 ? revenueData[0].totalRevenue : 0;

    // 📅 Monthly Revenue
    const monthlyRevenue = await Order.aggregate([
      { $match: { status: "Delivered" } },
      {
        $group: {
          _id: { $month: "$createdAt" },
          revenue: { $sum: "$totalAmount" }
        }
      },
      { $sort: { "_id": 1 } }
    ]);

    const topProducts = await Order.aggregate([
  { $match: { status: "Delivered" } },
  { $unwind: "$items" },
  {
    $group: {
      _id: "$items.product",
      totalSold: { $sum: "$items.quantity" }
    }
  },
  { $sort: { totalSold: -1 } },
  { $limit: 5 }
]);
const partnerPerformance = await Order.aggregate([
  { $match: { status: "Delivered" } },
  {
    $group: {
      _id: "$deliveryPartner",
      totalDelivered: { $sum: 1 }
    }
  },
  { $sort: { totalDelivered: -1 } }
]);
    res.json({
      totalOrders,
      totalUsers,
      totalDeliveryPartners,
      totalRevenue,
      monthlyRevenue,
      topProducts,
      partnerPerformance
    });
    

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = { getDashboardStats };