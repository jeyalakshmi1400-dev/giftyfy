const Logo =require( "../models/Logo.js");

 const uploadLogo =async(req,res)=>{
    try{
        const logo =new Logo({
            image:req.file.filename
        });
        await logo.save();
        res.json({message:"Logo Uploaded",logo});
    }
    catch(error){
        res.status(500).json({message:error.message});
    }
};

 const getLogo =async(req,res)=>{
    const logo=await Logo.find().sort({createdAt:-1}).limit(1);
    res.json(logo);
};

module.exports={uploadLogo,getLogo};