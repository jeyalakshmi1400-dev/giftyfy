const DeliveryPartner = require("../models/DeliveryPartner");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

// REGISTER
const registerPartner = async (req, res) => {
  try {
    const { email, password } = req.body;

    const exists = await DeliveryPartner.findOne({ email });
    if (exists) {
      return res.status(400).json({ message: "Email already registered" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const partner = await DeliveryPartner.create({
      ...req.body,
      password: hashedPassword
    });

    res.status(201).json({
      message: "Registered successfully. Wait for admin approval."
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// LOGIN
const loginPartner = async (req, res) => {
  try {
    const { email, password } = req.body;

    const partner = await DeliveryPartner.findOne({ email });
    if (!partner) {
      return res.status(404).json({ message: "Partner not found" });
    }

    if (!partner.isApproved) {
      return res.status(403).json({ message: "Admin approval pending" });
    }

    const isMatch = await bcrypt.compare(password, partner.password);
    if (!isMatch) {
      return res.status(401).json({ message: "Invalid password" });
    }

    const token = jwt.sign(
      { id: partner._id, role: "delivery" },
      process.env.JWT_SECRET,
      { expiresIn: "7d" }
    );

    res.json({
      token,
      partner: {
        id: partner._id,
        name: partner.name,
        email: partner.email,
        pincode: partner.pincode
      }
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

module.exports = { registerPartner, loginPartner };