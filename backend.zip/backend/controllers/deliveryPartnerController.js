const DeliveryPartner = require("../models/DeliveryPartner");

const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

// ✅ GET ALL DELIVERY PARTNERS (ADMIN)
const getAllDeliveryPartners = async (req, res) => {
  try {
    const partners = await DeliveryPartner.find();
    res.json(partners);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ✅ APPROVE DELIVERY PARTNER
const approveDeliveryPartner = async (req, res) => {
  try {
    const partner = await DeliveryPartner.findById(req.params.id);

    if (!partner) {
      return res.status(404).json({ message: "Partner not found" });
    }

    partner.isApproved = true;
    await partner.save();

    res.json({ message: "Delivery partner approved successfully" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};



// REGISTER
const registerDeliveryPartner = async (req, res) => {
  try {
    const { name, email, password, phone, pincode } = req.body;

    const exists = await DeliveryPartner.findOne({ email });
    if (exists) {
      return res.status(400).json({ message: "Already registered" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const partner = await DeliveryPartner.create({
      name,
      email,
      phone,
      pincode,
      password: hashedPassword
    });

    res.status(201).json({
      message: "Registered successfully. Wait for admin approval.",
      partner
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// LOGIN
const loginDeliveryPartner = async (req, res) => {
  try {
    const { email, password } = req.body;

    const partner = await DeliveryPartner.findOne({ email });
    if (!partner) {
      return res.status(404).json({ message: "Partner not found" });
    }

    if (!partner.isApproved) {
      return res.status(403).json({ message: "Admin approval pending" });
    }

    const isMatch = await bcrypt.compare(password, partner.password);
    if (!isMatch) {
      return res.status(401).json({ message: "Invalid password" });
    }

    const token = jwt.sign(
      { id: partner._id, role: "delivery" },
      process.env.JWT_SECRET,
      { expiresIn: "7d" }
    );

    res.json({ token, partner });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};


// ✅ GET PARTNERS BY PINCODE (USED IN ORDER)
const getPartnersByPincode = async (pincode) => {
  return await DeliveryPartner.find({
    pincode: pincode,
    isApproved: true,
    isAvailable: true
  });
};
module.exports = {
    registerDeliveryPartner,
  loginDeliveryPartner,
  getAllDeliveryPartners,
  approveDeliveryPartner,
  getPartnersByPincode
};