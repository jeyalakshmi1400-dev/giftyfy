const Order = require("../models/Order");
const Cart = require("../models/Cart");
const DeliveryPartner = require("../models/DeliveryPartner");
const OrderRequest = require("../models/OrderRequest");
const { getPartnersByPincode } = require("./deliveryPartnerController");
const Offer = require("../models/Offer");
// =======================
// PLACE ORDER (USER)
// =======================
const placeOrder = async (req, res) => {
  try {
    const cart = await Cart.findOne({ user: req.user.id })
      .populate("items.product");

    if (!cart || cart.items.length === 0) {
      return res.status(400).json({ message: "Cart is empty" });
    }

    let total = 0;

    for (let item of cart.items) {
      if (!item.product) {
        return res.status(400).json({
          message: "Product not found in cart. Clear cart and re-add."
        });
      }

      total += item.product.price * item.quantity;
    }

    // 🎁 APPLY COUPON LOGIC
    let finalAmount = total;
    let appliedCoupon = null;

    if (req.body.couponCode) {
      const offer = await Offer.findOne({
        code: req.body.couponCode,
        isActive: true
      });

      if (!offer) {
        return res.status(400).json({ message: "Invalid coupon code" });
      }

      if (new Date() > offer.expiryDate) {
        return res.status(400).json({ message: "Coupon expired" });
      }

      if (total < offer.minOrderAmount) {
        return res.status(400).json({
          message: `Minimum order amount ₹${offer.minOrderAmount} required`
        });
      }

      finalAmount =
        total - (total * offer.discountPercentage) / 100;

      appliedCoupon = offer.code;
    }

    // 🧾 CREATE ORDER
    const order = await Order.create({
      user: req.user.id,
      items: cart.items,
      totalAmount: finalAmount,
      deliveryPincode: req.body.pincode,
      status: "Payment Pending",   // 🔥 professional flow
      couponUsed: appliedCoupon
    });

    // 🛒 CLEAR CART
    cart.items = [];
    await cart.save();

    res.status(201).json({
      message: "Order placed successfully",
      originalAmount: total,
      finalAmount,
      order
    });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
// =======================
// USER ORDERS
// =======================
const getMyOrders = async (req, res) => {
  const orders = await Order.find({ user: req.user.id }).populate({
    path: "items.product",
    model: "Products"
  });
  res.json(orders);
};

// =======================
// ADMIN – ALL ORDERS
// =======================
const getAllOrders = async (req, res) => {
  const orders = await Order.find()
    .populate("user")
    .populate({
      path: "items.product",
      model: "Products"
    });
  res.json(orders);
};

// =======================
// ADMIN – UPDATE STATUS
// =======================
const updateOrderStatus = async (req, res) => {
  try {
    const { status } = req.body;

    const order = await Order.findById(req.params.id);
    if (!order) {
      return res.status(404).json({ message: "Order not found" });
    }

    order.status = status;
    await order.save();

    // 🔥 WHEN ADMIN CONFIRMS → CREATE DELIVERY REQUEST
    if (status === "Shipped") {

  const partners = await getPartnersByPincode(order.deliveryPincode);

  console.log("Order Pincode:", order.deliveryPincode);
  console.log("Partners Found:", partners.length);

  for (let partner of partners) {
    await OrderRequest.create({
      order: order._id,
      deliveryPartner: partner._id
    });
  }
}

    res.json({
      message: "Order status updated successfully",
      order
    });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// =======================
// ADMIN – MANUAL ASSIGN
// =======================
const assignDeliveryPartner = async (req, res) => {
  try {
    const { deliveryPartnerId } = req.body;

    const order = await Order.findById(req.params.id);
    if (!order) {
      return res.status(404).json({ message: "Order not found" });
    }

    const partner = await DeliveryPartner.findById(deliveryPartnerId);
    if (!partner) {
      return res.status(404).json({ message: "Delivery partner not found" });
    }

    order.deliveryPartner = deliveryPartnerId;
    order.status = "Shipped";
    await order.save();

    res.json({
      message: "Delivery partner assigned successfully",
      order
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// 🚚 DELIVERY PARTNER ACCEPT ORDER
const acceptOrder = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);

    if (!order) {
      return res.status(404).json({ message: "Order not found" });
    }

    if (order.status !== "Pending") {
      return res.status(400).json({ message: "Order already assigned" });
    }

    order.deliveryPartner = req.user.id; // delivery partner id
    order.status = "Assigned";

    await order.save();

    res.json({ message: "Order accepted successfully", order });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};


// 🚚 DELIVERY STATUS UPDATE
const updateDeliveryStatus = async (req, res) => {
  try {
    const { status } = req.body;

    const order = await Order.findById(req.params.id);

    if (!order) {
      return res.status(404).json({ message: "Order not found" });
    }

    // Only assigned delivery partner can update
    if (!order.deliveryPartner || order.deliveryPartner.toString() !== req.user.id) {
      return res.status(403).json({ message: "Not authorized" });
    }

    // Proper status flow validation
    if (status === "Out for Delivery" && order.status !== "Assigned") {
      return res.status(400).json({ message: "Order must be Assigned first" });
    }

    if (status === "Delivered" && order.status !== "Out for Delivery") {
      return res.status(400).json({ message: "Order must be Out for Delivery first" });
    }

    order.status = status;
    await order.save();

    res.json({
      message: "Delivery status updated successfully",
      order
    });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ❌ USER CANCEL ORDER
const cancelOrder = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);

    if (!order) {
      return res.status(404).json({ message: "Order not found" });
    }

    // 🔐 Only order owner can cancel
    if (order.user.toString() !== req.user.id) {
      return res.status(403).json({ message: "Not authorized" });
    }

    // 🚫 Already cancelled
    if (order.status === "Cancelled") {
      return res.status(400).json({ message: "Order already cancelled" });
    }

    // 🚫 Cannot cancel after shipping
    if (
      order.status === "Shipped" ||
      order.status === "Assigned" ||
      order.status === "Out for Delivery" ||
      order.status === "Delivered"
    ) {
      return res.status(400).json({
        message: "Order cannot be cancelled after shipping"
      });
    }

    // 🧠 Store previous status before changing
    const previousStatus = order.status;

    // 💰 If payment already confirmed → request refund
    if (previousStatus === "Confirmed") {
      order.refundStatus = "Requested";
    }

    // ❌ Update order status
    order.status = "Cancelled";
    order.cancelReason = req.body.reason || "User cancelled";

    await order.save();

    res.json({
      message: "Order cancelled successfully",
      order
    });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// 💰 ADMIN PROCESS REFUND
const processRefund = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);

    if (!order) {
      return res.status(404).json({ message: "Order not found" });
    }

    if (order.refundStatus !== "Requested") {
      return res.status(400).json({ message: "No refund request found" });
    }

    order.refundStatus = "Processed";
    await order.save();

    res.json({
      message: "Refund processed successfully",
      order
    });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  placeOrder,
  getMyOrders,
  getAllOrders,
  updateOrderStatus,
  assignDeliveryPartner,
  acceptOrder,
  updateDeliveryStatus,
  cancelOrder,
  processRefund
};