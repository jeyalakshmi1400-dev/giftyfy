const mongoose = require("mongoose");

const orderSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User"
    },
    items: [
      {
        product: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "Product"
        },
        quantity: Number
      }
    ],
    totalAmount: Number,
    status: {
      type: String,
      default: "Pending"
    },
deliveryPincode: String,

deliveryPartner: {
  type: mongoose.Schema.Types.ObjectId,
  ref: "DeliveryPartner"
},
couponUsed: {
  type: String
},

refundStatus: {
  type: String,
  enum: ["Not Requested", "Requested", "Processed"],
  default: "Not Requested"
},
cancelReason: {
  type: String
}
  },
  { timestamps: true }
);

module.exports = mongoose.model("Order", orderSchema);