const mongoose = require("mongoose");

const deliveryPartnerSchema = new mongoose.Schema(
  {
    name: String,
    phone: String,
    email: { type: String, unique: true },
    password: { type: String, required: true },

    address: String,
    photo: String,

    aadharNumber: String,
    aadharImage: String,

    panNumber: String,
    panImage: String,

    vehicleType: String,
    vehicleNumber: String,

    drivingLicenseNo: String,
    drivingLicenseImage: String,

    pincode: String,

    accountHolderName: String,
    accountNumber: String,
    bankName: String,
    ifscCode: String,

    isApproved: { type: Boolean, default: false },
    isAvailable: { type: Boolean, default: true }
  },
  { timestamps: true }
);

module.exports = mongoose.model("DeliveryPartner", deliveryPartnerSchema);