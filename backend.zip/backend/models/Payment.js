const mongoose = require("mongoose");

const paymentSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User"
    },
    order: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Order"
    },
    razorpay_order_id: String,
    razorpay_payment_id: String,
    razorpay_signature: String,
    amount: Number,
    status: {
      type: String,
      default: "Pending" // Pending / Success / Failed
    }
  },
  { timestamps: true }
);

module.exports = mongoose.model("Payment", paymentSchema);