require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const path = require("path");


const app = express();
app.use(cors());
app.use(express.json());

app.use("/uploads", express.static(path.join(__dirname, "uploads")));
// ✅ MongoDB connect
mongoose
  .connect(process.env.MONGO_URI)
  .then(() => console.log("MongoDB connected ✅"))
  .catch((err) => console.log("Mongo error", err));

// ✅ Routes
const userRoutes = require("./routes/userRoutes");
app.use("/api/users", userRoutes);

const productRoutes = require("./routes/productRoutes");
app.use("/api/products", productRoutes);

const categoryRoutes = require("./routes/categoryRoutes");
app.use("/api/categories", categoryRoutes);


const cartRoutes = require("./routes/cartRoutes");
app.use("/api/cart", cartRoutes);


const orderRoutes = require("./routes/orderRoutes");
app.use("/api/orders", orderRoutes);

const deliveryPartnerRoutes=require("./routes/deliveryPartnerRoutes");
app.use("/api/delivery-partners", deliveryPartnerRoutes);

const deliveryAuthRoutes = require("./routes/deliveryPartnerAuthRoutes");
app.use("/api/delivery-partner/auth", deliveryAuthRoutes);


const orderRequestRoutes = require("./routes/orderRequestRoutes");
app.use("/api/order-requests", orderRequestRoutes);

const adminRoutes = require("./routes/adminRoutes");
app.use("/api/admin",adminRoutes);

const paymentRoutes = require("./routes/paymentRoutes");
app.use("/api/payments", paymentRoutes);


const offerRoutes = require("./routes/offerRoutes");
app.use("/api/offers", offerRoutes);



const bannerRoutes =require("./routes/bannerRoutes");
app.use("/api/banner",bannerRoutes);


const logoRoutes =require("./routes/logoRoutes");
app.use("/api",logoRoutes);
app.use("/uploads",express.static("uploads"));

// ✅ PORT from .env
const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});